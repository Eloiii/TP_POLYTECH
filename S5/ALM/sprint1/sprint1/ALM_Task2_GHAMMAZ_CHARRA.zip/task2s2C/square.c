int square(int a)
{
    a = a * a;

    return a;
}