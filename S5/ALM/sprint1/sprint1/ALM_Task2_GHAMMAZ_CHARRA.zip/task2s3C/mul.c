int mul(int a, int b, int c, int d , int e , int f)
{
    return a * b * c *d * e * f;
}
