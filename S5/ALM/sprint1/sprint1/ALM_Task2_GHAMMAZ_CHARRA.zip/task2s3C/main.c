int mul(int a, int b, int c, int d , int e , int f);

int main(void)
{
    int res1,res2,res;
    
    res1 = mul(10, 4, 8, 4, 2, 3);
    res2 = mul(9, 1, 7, 14, 65, 9);
    res= res1+res2;
    return res;
}

