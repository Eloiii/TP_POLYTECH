#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>

#include "../task3/math.c"
#include "array.c"

/*
 * Notre point d'entrée habituel.
 * Maintenant nous pouvons reconnaître que c'est une fonction, 
 * comme les autres, c'est seulement la première appelée:
 */
int main(int nargs, char** args) {

  /*
   *  ECRIVEZ VOS TESTS ICI
   */
  return 0; 
}
