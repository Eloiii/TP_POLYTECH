/*
 * Vous pouvez ignorer les deux lignes suivantes.
 */
#include <stdint.h>
#include <stdio.h>

/*
 * Notre point d'entrée pour l'exécution.
 * Rappel: l'exécution commence toujours par la fonction main.
 */
void main(void) {
  printf("Hello World! \n");
  return;
}
